The sample application for cicd pipeline
