#!/bin/bash -xe
systemctl enable --now app.service
