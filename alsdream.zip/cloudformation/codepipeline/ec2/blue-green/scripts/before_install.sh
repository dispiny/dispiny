#!/bin/bash -xe
systemctl disable --now app.service
