#!/bin/bash
if [ ! -d /opt/app ]; then
    mkdir -p /opt/app
fi