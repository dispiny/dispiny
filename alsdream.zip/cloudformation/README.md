# CloudFormation template

CloudFormation templates for high productivity
