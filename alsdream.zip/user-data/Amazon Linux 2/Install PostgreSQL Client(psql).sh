#!/bin/bash
sudo amazon-linux-extras install postgresql14 -y

###### Connection Commands #####
### psql --host=localhost --username=postgres --password