#cloud-boothook
#!/bin/bash
chmod 700 /home/ec2-user/.ssh
chmod 600 /home/ec2-user/.ssh/authorized_keys
chmod 700 /home/ec2-user
