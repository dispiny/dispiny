#!/bin/bash
nohup python3 /root/app.pyc > /dev/null 2> dev/null <dev/null &