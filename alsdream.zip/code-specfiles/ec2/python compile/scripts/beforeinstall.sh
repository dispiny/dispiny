#!/bin/bash
pip3 install pytest Flask pytest-flask